# DESCRIPTION:
abarodaw_proj1.py - Breadth First Algorithm for 8-puzzle problem.
plot_path.py - Python script to help visualise the steps.

# ENVIRONMENT USED:
JetBrains PyCharm Community Edition

# LIBRARIES USED:
Install the following libraries through the Pycharm IDE. Type the library name and if the IDE doesn't detect it, there will be a yellow line below the library name. Hover over the yellow line and option will pop up to install the library/package.

1. copy

# GETTING STARTED:
Install the necessary libraries to have the code set up for running.


# RUNNING THE CODE:
Click the play button on the top right corner or use the shortcut (Shift+F10).

## INSTRUCTIONS:
abarodaw_proj1.py - Before running the script, enter the START STATE on line 12 and enter the GOAL STATE on line 19. Make sure the format/syntax of the input to the variables is same as shown below as example:

node_state_i_input = [[1, 6, 7], [2, 0, 5], [4, 3, 8]]
goal_state_input = [[1, 4, 7], [2, 5, 8], [3, 0, 6]]





